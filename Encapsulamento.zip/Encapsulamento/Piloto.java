public class Piloto {

    String nome;
    Integer idade;
    Integer habilidade;
    Double peso;

    public Piloto(String nome, Double peso) {
        this.nome = nome;
        this.peso = peso;
    }
}
