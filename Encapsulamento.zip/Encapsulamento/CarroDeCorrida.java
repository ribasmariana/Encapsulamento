public class CarroDeCorrida {

    private String identificacao;
    private Double velocidadeAtual = 0.0;
    private Double velocidadeMaxima = 180.0;
    private Piloto piloto;

    public CarroDeCorrida(String identificacao, Piloto piloto) {
        this.identificacao = identificacao;
        this.piloto = piloto;
    }

    void acelerar() {
        this.velocidadeAtual += 10;
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public Double getVelocidadeAtual() {
        return velocidadeAtual;
    }

    public Double getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    public Piloto getPiloto() {
        return piloto;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public void setVelocidadeMaxima(Double velocidadeMaxima) {
        this.velocidadeMaxima = velocidadeMaxima;
    }

    public void setPiloto(Piloto piloto) {
        this.piloto = piloto;
    }
}
