public class Main {

    public static void main(String[] args) {
        Piloto piloto = new Piloto("Lewis", 86.0);

        CarroDeCorrida carroVelocidade = new CarroDeCorrida("44", piloto);

        Piloto pilotoTrapaceiro = new Piloto("Max", 76.00);

        CarroDeCorrida carroTrapaceiro = new CarroDeCorrida("01", pilotoTrapaceiro);
        carroTrapaceiro.setVelocidadeMaxima(200.00);

        carroVelocidade.acelerar();
        carroTrapaceiro.acelerar();
        carroVelocidade.acelerar();
        carroTrapaceiro.acelerar();

        if (carroTrapaceiro.getVelocidadeAtual() > carroVelocidade.getVelocidadeAtual()){
            System.out.println("Trapaceiro venceu! Velocidade: " + carroVelocidade.getVelocidadeAtual());
        }else{
            System.out.println("Velocidade venceu! Velocidade: "+ carroTrapaceiro.getVelocidadeAtual());
        }


    }

}
